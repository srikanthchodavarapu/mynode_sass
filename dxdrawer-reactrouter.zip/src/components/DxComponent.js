import React from "react";

import "devextreme/dist/css/dx.common.css";
import "devextreme/dist/css/dx.light.css";
import "./DxComponent.css";

import { Drawer } from "devextreme-react/drawer";
import { Toolbar, Item } from "devextreme-react/toolbar";
import NavigationList from "./NavigationList.js";

import { Router, Route } from "react-router-dom";

import Inbox from "./views/Inbox.js";
import Trash from "./views/Trash.js";
import SentMail from "./views/SentMail.js";
import Spam from "./views/Spam.js";

import history from "./history";

class DxComponent extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      isOpened: false
    };
    this.buttonOptions = {
      icon: "menu",
      onClick: () => {
        this.setState({ isOpened: !this.state.isOpened });
      }
    };
  }
  render() {
    return (
      <React.Fragment>
        <Toolbar id="toolbar">
          <Item
            widget="dxButton"
            options={this.buttonOptions}
            location="before"
          />
        </Toolbar>
        <Drawer
          minSize={37}
          height={250}
          revealMode="expand"
          openedStateMode="overlap"
          component={NavigationList}
          opened={this.state.isOpened}
        >
          <div id="view">
            <Router history={history}>
              <div>
                <Route exact path="/" component={Inbox} />
                <Route exact path="/inbox" component={Inbox} />
                <Route exact path="/sent-mail" component={SentMail} />
                <Route exact path="/spam" component={Spam} />
                <Route exact path="/trash" component={Trash} />
              </div>
            </Router>
          </div>
        </Drawer>
      </React.Fragment>
    );
  }
}
export default DxComponent;
