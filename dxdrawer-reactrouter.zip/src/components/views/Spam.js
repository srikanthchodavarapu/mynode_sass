import React from "react";
import { Button } from "devextreme-react";

class Spam extends React.Component {
  render() {
    return <Button text="Spam" onClick={() => alert("This is Spam")} />;
  }
}

export default Spam;
