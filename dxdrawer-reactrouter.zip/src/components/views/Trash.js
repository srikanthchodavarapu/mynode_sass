import React from "react";
import { Button } from "devextreme-react";

class Trash extends React.Component {
  render() {
    return <Button text="Trash" onClick={() => alert("This is Trash")} />;
  }
}

export default Trash;
