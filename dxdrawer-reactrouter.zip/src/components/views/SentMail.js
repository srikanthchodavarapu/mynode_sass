import React from "react";
import { Button } from "devextreme-react";

class SentMail extends React.Component {
  render() {
    return (
      <Button text="Sent Mail" onClick={() => alert("This is Sent Mail")} />
    );
  }
}

export default SentMail;
