import React from "react";
import { Button } from "devextreme-react";

class Inbox extends React.Component {
  render() {
    return <Button text="Inbox" onClick={() => alert("This is Inbox")} />;
  }
}

export default Inbox;
