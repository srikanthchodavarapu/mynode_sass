import React from "react";
import List from "devextreme-react/list.js";
import history from "./history";

const navigation = [
  { id: 1, text: "Inbox", icon: "message", filePath: "inbox" },
  { id: 2, text: "Sent Mail", icon: "check", filePath: "sent-mail" },
  { id: 3, text: "Trash", icon: "trash", filePath: "trash" },
  { id: 4, text: "Spam", icon: "mention", filePath: "spam" }
];

class NavigationList extends React.PureComponent {
  loadView(e) {
    history.push(e.addedItems[0].filePath);
  }
  render() {
    return (
      <React.Fragment>
        <List
          items={navigation}
          width={200}
          selectionMode="single"
          onSelectionChanged={this.loadView}
          elementAttr={{
            class: "panel-list dx-theme-accent-as-background-color"
          }}
        />
      </React.Fragment>
    );
  }
}
export default NavigationList;
