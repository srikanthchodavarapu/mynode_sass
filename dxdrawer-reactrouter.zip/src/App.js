import React, { Component } from "react";
import DxComponent from "./components/DxComponent";

class App extends Component {
  render() {
    return (
      <div className="App">
        <DxComponent />
      </div>
    );
  }
}
export default App;
